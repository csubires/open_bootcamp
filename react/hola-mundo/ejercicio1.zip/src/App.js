import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Hola</h1>
        <showComponent></showComponent>
        <showComponent />
      </header>
    </div>
  );
}

export default App;
