import './App.css';
import { LoginFormContainer } from './components/container/LoginFormContainer';

function AppReduxSaga() {
    return (
        <div className="AppReduxSaga">
            <span>Prueba</span>
        <LoginFormContainer></LoginFormContainer>
        </div>
    );
}

export default AppReduxSaga;