import './App.css';
// import { Ejercicio2 } from './components/pure/ejercicio2';
import { Ejercicio3 } from './components/pure/ejercicio3';
import { Ejercicio4 } from './components/pure/ejercicio4';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <Ejercicio4></Ejercicio4>
        <h5>Listado de contactos</h5>
        <Ejercicio3></Ejercicio3>
      </header>
    </div>
  );
}

export default App;
