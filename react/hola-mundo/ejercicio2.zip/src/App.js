import './App.css';
import { Ejercicio2 } from './components/pure/ejercicio2';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Hola !</h1>
        <renderContact></renderContact>
        <showComponent />
        <Ejercicio2></Ejercicio2>
      </header>
    </div>
  );
}

export default App;
