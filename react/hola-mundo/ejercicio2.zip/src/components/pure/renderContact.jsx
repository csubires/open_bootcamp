import React from 'react';
import { Contacto } from "../../models/contacto.class"
import PropTypes from 'prop-types';


const renderContact = (contacto) => {
    return (
        <div>
            Nombre: <h3>{contacto.nombre}</h3>
            Apellidos: <h3>{contacto.apellido}</h3>
            Email: <i>{contacto.email}</i>
            Estado: <span>{contacto.conectado ? 'Contacto En Línea': 'Contacto No Disponible'}</span>
        </div>
    );

}

renderContact.propTypes = {
    contacto: PropTypes.instanceOf(Contacto)
};